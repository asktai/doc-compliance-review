---
industry: 医药
slug: pharma
display_name: 文档合规审查助手AI合同（医药行业版）
common_roles: [申办者, 供货方, 采购方]
positions:
  - 质量与合规优先（GMP/GSP/GCP）
  - 临床/研发成果与数据归我方
  - 责任分层：对外先行赔付、对内按过错追偿
trigger_keywords: [医药, 药品, 制药, 临床, CRO, 生物医药, 医疗器械, 原料药, 中药, 中药材, 中药饮片, 中成药, 配方颗粒, 破壁饮片, 破壁颗粒, 化药, 生物药, 原研药, 处方药, OTC, 非OTC, 小包装饮片, 养生汤, 养生堂, 养生学院, 养生研究院, 大健康, 养生, 效期, 推广, 疗效, 功效, 广审, 二票制, 两票制, 代理人, 佣金, 服务商, 代理商, 电商, 新零售, 终端, 票折, 医药代表, 省标, 地方标, 贯标, 炮制规范, 第三终端, 合作伙伴, 学术推广, 代加工, 委托生产, 贴牌, 品牌授权, 商标许可, OEM, ODM, 预包装, 农产品, 农副产品, 药食同源, 食药同源, 调味料, 道地, 地道, 原研, 仿制, 包装, 标签]
inherits: core
core_version: 3.0.0
severity_defaults: 长周期（外观15–30日；质量=有效期/保质期）
effective_date: 2026-09-18
last_revised: 2026-09-20
revision:
  - version: "3.0.0"
    date: "2026-09-16"
    summary: 行业包建立（继承 core 通用库，只写差异与增量）
  - version: "3.2.0"
    date: "2026-09-17"
    summary: 产品更名，display_name 同步更新
---
